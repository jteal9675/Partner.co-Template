import React from 'react';

const FinalCTA = () => {
  const scrollToSection = (id: string) => {
    const element = document.getElementById(id);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <section className="py-20 bg-gradient-to-br from-[#004830] via-[#004730] to-[#ffa07a]">
      <div className="container mx-auto px-4">
        <div className="max-w-4xl mx-auto text-center">
          <h2 className="text-4xl md:text-6xl font-bold text-white mb-6 leading-tight">
            Every Day You Wait Is a Day You Could Be 
            <span className="block text-[#ffa07a]">Feeling Better</span>
          </h2>
          
          <p className="text-xl text-emerald-100 mb-12 max-w-3xl mx-auto leading-relaxed">
            Or building the freedom you've been dreaming about. Let's make it happen together. 
            Your transformation starts with a single decision.
          </p>

          <div className="relative">
            <button 
              onClick={() => window.open('https://calendly.com/rootedvitality/meeting')}
              className="bg-white text-emerald-800 px-16 py-6 rounded-full text-xl font-bold hover:bg-amber-50 transform hover:scale-105 transition-all duration-300 shadow-2xl hover:shadow-3xl border-4 border-white/20"
            >
              Start Today
            </button>
            
            {/* Animated pulse effect */}
            <div className="absolute inset-0 rounded-full bg-white/20 animate-ping pointer-events-none"></div>
          </div>

          <p className="text-emerald-200 mt-8 text-lg">
            Join thousands who've already transformed their lives
          </p>
        </div>
      </div>
    </section>
  );
};

export default FinalCTA;