import React from 'react';
import { Facebook, Instagram, Youtube, Mail, Phone, MapPin } from 'lucide-react';

const Footer = () => {
  const scrollToSection = (id: string) => {
    const element = document.getElementById(id);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <footer id="contact" className="bg-emerald-900 text-white py-16">
      <div className="container mx-auto px-4">
        <div className="max-w-6xl mx-auto">
          <div className="grid md:grid-cols-4 gap-8 mb-12">
            {/* Company Info */}
            <div className="md:col-span-2">
              <h3 className="text-2xl font-bold text-[#ffa07a] mb-4">
                Rooted Vitality
              </h3>
              <p className="text-emerald-100 mb-6 leading-relaxed">
                Empowering people to achieve optimal wellness while building sustainable income streams. 
                Your journey to health and financial freedom starts here.
              </p>
              <div className="flex space-x-4">
                <a 
                  href="https://www.facebook.com/share/19XmzFeAHw/" 
                  target="_blank" 
                  rel="noopener noreferrer"
                  className="w-10 h-10 bg-[#004830] rounded-full flex items-center justify-center hover:bg-[#004830] transition-colors"
                >
                  <Facebook size={26} className="text-white" />
                </a>
                <a 
                  href="https://www.instagram.com/rootedvitality.official?igsh=dnVhazBpMnlqanI2" 
                  target="_blank" 
                  rel="noopener noreferrer"
                  className="w-10 h-10 bg-[#004830] rounded-full flex items-center justify-center hover:bg-[#004830] transition-colors"
                >
                  <Instagram size={30} className="text-white" />
                </a>
                <a 
                  href="https://youtube.com/@rootedvitality.official?si=40K0ljFwKweYz271" 
                  target="_blank" 
                  rel="noopener noreferrer"
                  className="w-10 h-10 bg-[#004830] rounded-full flex items-center justify-center hover:bg-[#004830] transition-colors"
                >
                  <Youtube size={33} className="text-white" />
                </a>
              </div>
            </div>

            {/* Quick Links */}
            <div>
              <h4 className="text-lg font-semibold text-[#ffa07a] mb-4">
                Quick Links
              </h4>
              <ul className="space-y-2">
                <li>
                  <button 
                    onClick={() => scrollToSection('home')}
                    className="text-emerald-100 hover:text-white transition-colors"
                  >
                    Home
                  </button>
                </li>
                <li>
                  <button 
                    onClick={() => scrollToSection('wellness')}
                    className="text-emerald-100 hover:text-white transition-colors"
                  >
                    Wellness
                  </button>
                </li>
                <li>
                  <button 
                    onClick={() => scrollToSection('income')}
                    className="text-emerald-100 hover:text-white transition-colors"
                  >
                    Income Opportunity
                  </button>
                </li>
                <li>
                  <a href="#" className="text-emerald-100 hover:text-white transition-colors">
                    Privacy Policy
                  </a>
                </li>
                <li>
                  <a href="#" className="text-emerald-100 hover:text-white transition-colors">
                    Terms of Service
                  </a>
                </li>
              </ul>
            </div>

            {/* Contact Info */}
            <div>
              <h4 className="text-lg font-semibold text-[#ffa07a] mb-4">
                Contact Us
              </h4>
              <div className="space-y-3">
                <div className="flex items-center">
                  <Mail size={16} className="text-emerald-300 mr-3" />
                  <span className="text-emerald-100">j.teal9675@gmail.com</span>
                </div>
                <div className="flex items-center">
                  <Phone size={16} className="text-emerald-300 mr-3" />
                  <span className="text-emerald-100">1-207-390-5398</span>
                </div>
                <div className="flex items-start">
                  <MapPin size={16} className="text-emerald-300 mr-3 mt-1" />
                  <span className="text-emerald-100">Serving clients worldwide</span>
                </div>
              </div>
            </div>
          </div>

          {/* Bottom Bar */}
          <div className="border-t border-emerald-800 pt-8 flex flex-col md:flex-row justify-between items-center">
            <p className="text-emerald-300 text-sm mb-4 md:mb-0">
              © 2024 Rooted Vitality. All rights reserved.
            </p>
            <p className="text-emerald-300 text-sm">
              Partnered with Partner.co for your success
            </p>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;