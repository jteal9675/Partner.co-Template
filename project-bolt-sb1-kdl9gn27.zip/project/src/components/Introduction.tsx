import React from 'react';
import { Heart, Users, Sparkles } from 'lucide-react';

const Introduction = () => {
  return (
    <section className="py-20" style={{ backgroundColor: '#fdf8f7' }}>
      <div className="container mx-auto px-4">
        <div className="max-w-4xl mx-auto text-center">
          <div className="flex flex-col md:flex-row items-center gap-8 mb-12">
            <div className="flex-2">
              <h2 className="text-3xl md:text-4xl font-bold mb-6" style={{ color: '#004830' }}>
                Welcome to Your Journey
              </h2>
              <p className="text-lg leading-relaxed" style={{ color: '#4a4a4a' }}>
                At Rooted Vitality, we combine proven wellness solutions with simple,
                powerful ways to earn income and live life on your terms. Your path to
                transformation starts with a single step.
              </p>
            </div>
          </div>

          <div className="grid md:grid-cols-3 gap-8 mt-16">
            <div className="text-center group">
              <div className="w-16 h-16 mx-auto mb-4 rounded-full flex items-center justify-center bg-[#004830] hover:bg-[#006644] transition-colors">
                <Heart size={24} className="text-[#ffa07a]" />
              </div>
              <h3 className="text-xl font-semibold mb-2" style={{ color: '#004830' }}>Proven Wellness</h3>
              <p className="text-gray-600">Science-backed solutions for natural health and vitality</p>
            </div>

            <div className="text-center group">
              <div className="w-16 h-16 mx-auto mb-4 rounded-full flex items-center justify-center bg-[#004830] hover:bg-[#006644] transition-colors">
                <Sparkles size={24} className="text-[#ffa07a]" />
              </div>
              <h3 className="text-xl font-semibold mb-2" style={{ color: '#004830' }}>Income Growth</h3>
              <p className="text-gray-600">Build sustainable income streams doing what you love</p>
            </div>

            <div className="text-center group">
              <div className="w-16 h-16 mx-auto mb-4 rounded-full flex items-center justify-center bg-[#004830] hover:bg-[#006644] transition-colors">
                <Users size={24} className="text-[#ffa07a]" />
              </div>
              <h3 className="text-xl font-semibold mb-2" style={{ color: '#004830' }}>Community Support</h3>
              <p className="text-gray-600">Join a thriving community of like-minded individuals</p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Introduction;