import React from 'react';
import { MessageCircle, FileText, Heart } from 'lucide-react';

const HowWeWork = () => {
  return (
    <section className="py-20 bg-white">
      <div className="container mx-auto px-4">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-4xl md:text-5xl font-bold text-emerald-800 mb-6">
              How We Work Together
            </h2>
            <p className="text-xl text-gray-700">
              Your journey to wellness and success is just three simple steps away
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-8 lg:gap-12">
            <div className="text-center group">
              <div className="relative mb-8">
                <div className="w-24 h-24 mx-auto rounded-full bg-gradient-to-br from-[#004830] to-[#004930] flex items-center justify-center shadow-lg group-hover:shadow-xl transition-shadow">
                  <MessageCircle size={32} className="text-white" />
                </div>
                <div className="absolute -top-2 -right-2 w-8 h-8 bg-[#004830] text-white rounded-full flex items-center justify-center font-bold text-sm">
                  1
                </div>
              </div>
              <h3 className="text-2xl font-bold text-emerald-800 mb-4">
                Connect with Us
              </h3>
              <p className="text-gray-700 leading-relaxed">
                We schedule a personal consultation 
                to understand your goals and needs. No pressure, just genuine conversation.
              </p>
            </div>

            <div className="text-center group">
              <div className="relative mb-8">
                <div className="w-24 h-24 mx-auto rounded-full bg-gradient-to-br from-[#ffa07a] to-[#ffa08a] flex items-center justify-center shadow-lg group-hover:shadow-xl transition-shadow">
                  <FileText size={32} className="text-white" />
                </div>
                <div className="absolute -top-2 -right-2 w-8 h-8 bg-[#004830] text-white rounded-full flex items-center justify-center font-bold text-sm">
                  2
                </div>
              </div>
              <h3 className="text-2xl font-bold text-emerald-800 mb-4">
                Create Your Plan
              </h3>
              <p className="text-gray-700 leading-relaxed">
                Together, we'll design a personalized plan that fits your lifestyle. 
                Whether it's wellness products or building income, we'll map out your path.
              </p>
            </div>

            <div className="text-center group">
              <div className="relative mb-8">
                <div className="w-24 h-24 mx-auto rounded-full bg-gradient-to-br from-[#004830] to-[#ffa07a] flex items-center justify-center shadow-lg group-hover:shadow-xl transition-shadow">
                  <Heart size={32} className="text-white" />
                </div>
                <div className="absolute -top-2 -right-2 w-8 h-8 bg-[#004830] text-white rounded-full flex items-center justify-center font-bold text-sm">
                  3
                </div>
              </div>
              <h3 className="text-2xl font-bold text-emerald-800 mb-4">
                Live Your Best Life
              </h3>
              <p className="text-gray-700 leading-relaxed">
                With ongoing support and proven systems, you'll start seeing results. 
                We're with you every step of the way on your transformation journey.
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default HowWeWork;