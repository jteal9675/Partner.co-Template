import React from 'react';

const WellnessSection = () => {
  return (
    <section
      id="wellness"
      className="py-20"
      style={{ backgroundColor: '#e0f0dc' }} // off-green background
    >
      <div className="container mx-auto px-4">
        <div className="max-w-6xl mx-auto">
          {/* Header + Subtext */}
          <div className="text-center mb-16">
            <h2 className="text-4xl md:text-5xl font-bold mb-6 text-emerald-900">
              Your Health, Balanced Naturally
            </h2>
            <p className="text-xl max-w-3xl mx-auto leading-relaxed text-gray-700">
              Speed up your slim down, support your body's natural balance, and feel energized —
              without complicated routines. Our Body Balancing Drops work with your body's natural
              rhythms to help you feel your absolute best.
            </p>
          </div>

          {/* YouTube Video */}
          <div className="mb-12 flex justify-center">
            <div className="w-full md:w-3/4 lg:w-2/3 aspect-video rounded-2xl shadow-lg overflow-hidden">
              <iframe
                width="100%"
                height="100%"
                src="https://www.youtube.com/embed/6ZpPfi2c-LQ"
                title="Wellness Video"
                frameBorder="0"
                allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                allowFullScreen
              ></iframe>
            </div>
          </div>

          {/* Button + 4-Pack Tip */}
          <div className="text-center">
            <a
              href="https://partner.co/s/YjdmYTNlMjVm"
              target="_blank"
              rel="noopener noreferrer"
              className="bg-gradient-to-r from-emerald-600 to-emerald-700 text-white px-12 py-4 rounded-full text-lg font-semibold hover:from-emerald-700 hover:to-emerald-800 transform hover:scale-105 transition-all duration-300 shadow-lg hover:shadow-xl inline-block"
            >
              Start With 15% Off Your Wellness Journey
            </a>

            {/* 4-Pack Tip with enhanced hover */}
            <p className="mt-4 text-sm text-gray-700">
              Psst… Split a 4-Pack with friends and your box is FREE —{" "}
              <a
                href="https://partner.co/s/MDI3N2I3NTBk"
                target="_blank"
                rel="noopener noreferrer"
                className="underline hover:text-emerald-800 hover:font-semibold transition-all"
              >
                Save $250!
              </a>
            </p>
          </div>
        </div>
      </div>
    </section>
  );
};

export default WellnessSection;