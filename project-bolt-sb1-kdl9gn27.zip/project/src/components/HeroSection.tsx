import React, { useRef, useEffect } from "react";

const HeroSection: React.FC = () => {
  const videoRef = useRef<HTMLVideoElement>(null);

  useEffect(() => {
    if (videoRef.current) {
      videoRef.current.play().catch(() => {
        // autoplay might fail if not muted
      });
    }
  }, []);

  return (
    <section id="home" className="min-h-screen relative overflow-hidden">
      {/* Video Background */}
      <video
        ref={videoRef}
        autoPlay
        muted
        loop
        playsInline
        preload="auto"
        className="absolute inset-0 w-full h-full object-cover"
      >
        <source
          src="https://res.cloudinary.com/dijaamjbn/video/upload/v1756410611/e314b0ee-c860-42a1-bff9-26402f668adc_xz1bhw.mp4"
          type="video/mp4"
        />
        Your browser does not support the video tag.
      </video>

      {/* Overlay */}
      <div className="absolute inset-0 bg-black/30"></div>

      {/* Content */}
      <div className="relative z-10 container mx-auto px-4 h-screen flex flex-col justify-center">
        <div className="text-center max-w-4xl mx-auto">
          <h1
            className="text-5xl md:text-7xl font-bold mb-4 leading-tight"
            style={{ textShadow: "1px 1px 2px rgba(0,0,0,0.5)" }}
          >
            <span className="block" style={{ color: "#efdecd" }}>
              Wellness That
            </span>
            <span className="block" style={{ color: "#f6d7b0" }}>
              Runs Deep
            </span>
          </h1>

          <div className="flex flex-col sm:flex-row gap-6 justify-center items-center mt-14">
            <button
              onClick={() => {
                document.getElementById("income")?.scrollIntoView({ behavior: "smooth" });
              }}
              className="bg-[#004830] text-white px-8 py-4 rounded-full text-lg font-semibold hover:bg-[#006644] transform hover:scale-105 transition-all duration-300 shadow-lg hover:shadow-xl w-full sm:w-auto sm:min-w-64"
            >
              Get Paid
            </button>

            <a
              href="https://partner.co/s/ZTQxZWQwMzQ0"
              target="_blank"
              rel="noopener noreferrer"
              className="bg-[#ffa07a] text-white px-8 py-4 rounded-full text-lg font-semibold hover:bg-[#ff8c69] transform hover:scale-105 transition-all duration-300 shadow-lg hover:shadow-xl w-full sm:w-auto sm:min-w-64 text-center"
            >
              Get My Drops
            </a>
          </div>
        </div>
      </div>
    </section>
  );
};

export default HeroSection;