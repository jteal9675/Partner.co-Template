import React from 'react';
import { Users, Briefcase, TrendingUp } from 'lucide-react';

const IncomeSection = () => {
  const scrollToSection = (id: string) => {
    const element = document.getElementById(id);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <section id="income" className="py-20 bg-gradient-to-br from-amber-50 to-white">
      <div className="container mx-auto px-4">
        <div className="max-w-6xl mx-auto">
          {/* Header */}
          <div className="text-center mb-16">
            <h2 className="text-4xl md:text-5xl font-bold text-[#004830] mb-6">
              Turn Your Passion for Wellness into Income
            </h2>
            <p className="text-xl text-gray-700 max-w-3xl mx-auto leading-relaxed">
              We show you how to earn from home, work anywhere, and grow a business you love — 
              with full mentorship, tools, and a global product line. Your entrepreneurial journey 
              starts with the right support system.
            </p>
          </div>

          {/* Three Feature Cards */}
          <div className="grid md:grid-cols-3 gap-8 mb-12">
            <div className="bg-white p-8 rounded-2xl shadow-lg hover:shadow-xl transition-shadow group">
              <div className="w-16 h-16 mx-auto mb-6 rounded-full flex items-center justify-center bg-[#004830] group-hover:bg-[#006644] transition-colors">
                <Users size={24} className="text-[#ffa07a]" />
              </div>
              <h3 className="text-xl font-semibold text-[#004830] mb-4 text-center">Mentorship & Training</h3>
              <p className="text-gray-600 text-center">
                Get personalized guidance from successful entrepreneurs who've walked the path before you
              </p>
            </div>

            <div className="bg-white p-8 rounded-2xl shadow-lg hover:shadow-xl transition-shadow group">
              <div className="w-16 h-16 mx-auto mb-6 rounded-full flex items-center justify-center bg-[#004830] group-hover:bg-[#006644] transition-colors">
                <Briefcase size={24} className="text-[#ffa07a]" />
              </div>
              <h3 className="text-xl font-semibold text-[#004830] mb-4 text-center">Done-for-You Tools</h3>
              <p className="text-gray-600 text-center">
                Access our complete CRM system, appointment setting tools, and marketing materials
              </p>
            </div>

            <div className="bg-white p-8 rounded-2xl shadow-lg hover:shadow-xl transition-shadow group">
              <div className="w-16 h-16 mx-auto mb-6 rounded-full flex items-center justify-center bg-[#004830] group-hover:bg-[#006644] transition-colors">
                <TrendingUp size={24} className="text-[#ffa07a]" />
              </div>
              <h3 className="text-xl font-semibold text-[#004830] mb-4 text-center">Flexible Income Streams</h3>
              <p className="text-gray-600 text-center">
                Build multiple revenue streams that grow with you — from part-time side income to full-time freedom
              </p>
            </div>
          </div>

          {/* Highlight Box */}
          <div className="bg-gradient-to-r from-[#004830] to-[#ffa07a] rounded-2xl p-8 mb-12 text-white">
            <div className="max-w-4xl mx-auto text-center">
              <h3 className="text-2xl md:text-3xl font-bold mb-4">
                What Makes This Different?
              </h3>
              <p className="text-lg mb-6 opacity-90">
                We don't just give you products to sell. We give you a complete business system, 
                ongoing training, and a community of entrepreneurs who support each other's success.
              </p>
              <div className="grid md:grid-cols-2 gap-6 text-left">
                <div>
                  <h4 className="font-semibold mb-2">✓ Proven Business Model</h4>
                  <p className="opacity-80">Based on years of successful partnerships</p>
                </div>
                <div>
                  <h4 className="font-semibold mb-2">✓ Global Reach</h4>
                  <p className="opacity-80">Work with customers worldwide</p>
                </div>
                <div>
                  <h4 className="font-semibold mb-2">✓ Full Support</h4>
                  <p className="opacity-80">Never feel like you're going it alone</p>
                </div>
                <div>
                  <h4 className="font-semibold mb-2">✓ Scalable Growth</h4>
                  <p className="opacity-80">Start small, grow at your own pace</p>
                </div>
              </div>
            </div>
          </div>

          {/* CTA */}
          <div className="text-center">
            <button 
              onClick={() => window.open('https://calendly.com/rootedvitality/meeting')}
              className="bg-gradient-to-r from-[#ffa07a] to-[#ff875c] text-white px-12 py-4 rounded-full text-lg font-semibold hover:from-[#ff875c] hover:to-[#e76e47] transform hover:scale-105 transition-all duration-300 shadow-lg"
            >
              Start Your Journey
            </button>
          </div>
        </div>
      </div>
    </section>
  );
};

export default IncomeSection;