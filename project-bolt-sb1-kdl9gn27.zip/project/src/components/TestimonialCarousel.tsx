import React, { useState, useEffect } from 'react';
import { ChevronLeft, ChevronRight, Star } from 'lucide-react';

const TestimonialCarousel = () => {
  const [currentSlide, setCurrentSlide] = useState(0);

  const testimonials = [
    {
      name: "Pastor Randy Domingue",
      type: "Wellness Customer",
      text: "I order the drops and the rest is history in 6 months I lost 162lbs and kept most of it off. These drops have totally changed my life.",
      image: "/Pastor.jpg"
    },
    {
      name: "Mike Drew",
      type: "Business Partner",
      text: "It started as a side income and now I'm earning more than my corporate job. The mentorship and tools they provide are game-changing.",
      image: "/Mike.jpg"
    },
    {
      name: "Becky",
      type: "Wellness Customer",
      text: "I've personally lost over 100 pounds, and it's been a rollercoaster journey! After years of yo-yo dieting, I was stuck with those last stubborn pounds that just wouldn't budge-until now.",
      image: "/Becky.jpg"
    },
    {
      name: "Kat Dugan",
      type: "Business Partner",
      text: "Always here to help those who want to feel better by balancing hormones/gently releasing weight, and, those seeking to know Jesus!",
      image: "/Kat.jpg"
    }
  ];

  const nextSlide = () => {
    setCurrentSlide((prev) => (prev + 1) % testimonials.length);
  };

  const prevSlide = () => {
    setCurrentSlide((prev) => (prev - 1 + testimonials.length) % testimonials.length);
  };

  useEffect(() => {
    const timer = setInterval(nextSlide, 5000);
    return () => clearInterval(timer);
  }, []);

  return (
    <section className="py-20 bg-gradient-to-br from-white to-emerald-50">
      <div className="container mx-auto px-4">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-4xl md:text-5xl font-bold text-emerald-800 mb-6">
              Real People. Real Transformations.
            </h2>
            <p className="text-xl text-gray-700">
              See how Rooted Vitality has transformed lives and created opportunities
            </p>
          </div>

          <div className="relative">
            <div className="overflow-hidden rounded-2xl">
              <div 
                className="flex transition-transform duration-500 ease-in-out"
                style={{ transform: `translateX(-${currentSlide * 100}%)` }}
              >
                {testimonials.map((testimonial, index) => (
                  <div key={index} className="w-full flex-shrink-0">
                    <div className="bg-white p-8 md:p-12 shadow-lg">
                      <div className="flex flex-col md:flex-row items-center gap-8">
                        <div className="flex-shrink-0">
                          <img 
                            src={testimonial.image} 
                            alt={testimonial.name}
                            className="w-24 h-24 rounded-full object-cover shadow-lg"
                          />
                        </div>
                        
                        <div className="flex-1 text-center md:text-left">
                          <div className="flex justify-center md:justify-start mb-4">
                            {[...Array(5)].map((_, i) => (
                              <Star key={i} size={20} className="text-yellow-400 fill-current" />
                            ))}
                          </div>
                          
                          <blockquote className="text-lg text-gray-700 mb-6 italic">
                            "{testimonial.text}"
                          </blockquote>
                          
                          <div>
                            <div className="font-semibold text-emerald-800 text-lg">
                              {testimonial.name}
                            </div>
                            <div className="text-amber-600 font-medium">
                              {testimonial.type}
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Navigation Buttons */}
            <button 
              onClick={prevSlide}
              className="absolute left-4 top-1/2 transform -translate-y-1/2 bg-white/80 hover:bg-white text-emerald-800 p-3 rounded-full shadow-lg hover:shadow-xl transition-all duration-300"
            >
              <ChevronLeft size={24} />
            </button>
            
            <button 
              onClick={nextSlide}
              className="absolute right-4 top-1/2 transform -translate-y-1/2 bg-white/80 hover:bg-white text-emerald-800 p-3 rounded-full shadow-lg hover:shadow-xl transition-all duration-300"
            >
              <ChevronRight size={24} />
            </button>

            {/* Dots Indicator */}
            <div className="flex justify-center mt-8 space-x-2">
              {testimonials.map((_, index) => (
                <button
                  key={index}
                  onClick={() => setCurrentSlide(index)}
                  className={`w-3 h-3 rounded-full transition-all duration-300 ${
                    index === currentSlide 
                      ? 'bg-emerald-600 scale-125' 
                      : 'bg-emerald-200 hover:bg-emerald-300'
                  }`}
                />
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default TestimonialCarousel;