import React, { useState } from 'react';
import { Menu, X } from 'lucide-react';

const Header = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  const scrollToSection = (id: string) => {
    const element = document.getElementById(id);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
      setIsMenuOpen(false);
    }
  };

  // Updated menu items, 'about' removed
  const menuSections = ['home', 'wellness', 'income', 'contact'];

  return (
    <header className="bg-transparent absolute top-0 left-0 w-full z-50">
      <div className="container mx-auto px-4 py-4">
        <nav className="flex items-center justify-between">
          {/* Logo */}
          <div className="flex items-center gap-2">
            <img 
              src="/logo-3.png"
              alt="Rooted Vitality Logo" 
              className="h-20 w-auto"
            />
          </div>
          
          {/* Desktop Navigation */}
          <div className="hidden md:flex items-center space-x-8">
            {menuSections.map((section) => (
              <button
                key={section}
                onClick={() => scrollToSection(section)}
                className="text-white transition-colors hover:text-emerald-300"
                style={{ textShadow: '1px 1px 3px rgba(0,0,0,0.7)' }}
              >
                {section.charAt(0).toUpperCase() + section.slice(1)}
              </button>
            ))}
          </div>

          {/* Mobile Menu Button */}
          <button 
            className="md:hidden text-white"
            onClick={() => setIsMenuOpen(!isMenuOpen)}
          >
            {isMenuOpen ? <X size={24} /> : <Menu size={24} />}
          </button>
        </nav>

        {/* Mobile Navigation */}
        {isMenuOpen && (
          <div className="md:hidden mt-4 bg-black/30 backdrop-blur-sm rounded-md">
            <div className="flex flex-col space-y-4 p-4">
              {menuSections.map((section) => (
                <button
                  key={section}
                  onClick={() => scrollToSection(section)}
                  className="text-white hover:text-emerald-300 transition-colors"
                  style={{ textShadow: '1px 1px 3px rgba(0,0,0,0.7)' }}
                >
                  {section.charAt(0).toUpperCase() + section.slice(1)}
                </button>
              ))}
            </div>
          </div>
        )}
      </div>
    </header>
  );
};

export default Header;