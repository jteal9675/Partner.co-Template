import React from 'react';
import Header from './components/Header';
import HeroSection from './components/HeroSection';
import Introduction from './components/Introduction';
import WellnessSection from './components/WellnessSection';
import IncomeSection from './components/IncomeSection';
import TestimonialCarousel from './components/TestimonialCarousel';
import HowWeWork from './components/HowWeWork';
import FinalCTA from './components/FinalCTA';
import Footer from './components/Footer';

function App() {
  return (
    <div className="min-h-screen">
      <Header />
      <HeroSection />
      <Introduction />
      <WellnessSection />
      <IncomeSection />
      <TestimonialCarousel />
      <HowWeWork />
      <FinalCTA />
      <Footer />
    </div>
  );
}

export default App;